import { Component, OnInit, ViewChild, TemplateRef } from '@angular/core';
import { BsModalService, BsModalRef } from 'ngx-bootstrap/modal';
enum OPERATION_TYPE {
  ADD_LIST = "ADD_LIST",
  ADD_CARD = "ADD_CARD"
}

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {

  @ViewChild('newListForm') newListFormTemplateRef: TemplateRef<any>;
  @ViewChild('newTaskForm') newTaskFormTemplateRef: TemplateRef<any>;

  constructor(private bsModalService: BsModalService) { }
  newListFormFields;
  newTaskFormFields;
  selectedListIndex;
  listCollections = [];
  errorFields = {
    fieldsMissingError: false
  }
  dragAndDropElementRef = {
    listIndex: null,
    cardIndex: null
  }
  modalRefs: BsModalRef;
  availablePopupOperations = OPERATION_TYPE;

  ngOnInit() {
    this.listCollections = JSON.parse(sessionStorage.getItem('listCollections')) || [];
    this.sortCards();
  }

  /**
   * Driver function to toggle various pop-ups based upon operation type
   * @param operationType type of operation
   * @param lisIndex list index(optional param), reqd if card is required to be added in a list.
   */
  showNewListPopup(operationType: OPERATION_TYPE, lisIndex?): void {
    let computedTemplateRef;
    if (operationType == OPERATION_TYPE.ADD_LIST) {
      computedTemplateRef = this.newListFormTemplateRef;
      this.newListFormFields = {
        listTitle: '', date: (new Date()), availableCards: []
      }
    } else {
      computedTemplateRef = this.newTaskFormTemplateRef;
      this.newTaskFormFields = {
        cardTitle: '',
        cardDescription: '',
        cardCreationTime: (new Date())
      }
      this.selectedListIndex = lisIndex;
    }
    this.modalRefs = this.bsModalService.show(computedTemplateRef, { class: "modal-md" });
  }

  addNewList() {
    this.errorFields.fieldsMissingError = (this.newListFormFields.listTitle) ? false : true;
    if (this.errorFields.fieldsMissingError) return;
    this.listCollections.push(this.newListFormFields);
    this.updateSessionStorage();
    this.modalRefs.hide();
  }

  /**
   * 
   * @param selectedListIndex index of the list which is to be removed.
   */
  removeList(selectedListIndex): void {
    this.listCollections.splice(selectedListIndex, 1);
    this.updateSessionStorage();
  }


  /**Card utils starts here */
  addNewCard(): void {
    this.errorFields.fieldsMissingError = (this.newTaskFormFields.cardDescription && this.newTaskFormFields.cardTitle) ? false : true;
    if (this.errorFields.fieldsMissingError) return;
    this.listCollections[this.selectedListIndex].availableCards.push({ ...this.newTaskFormFields });
    this.updateSessionStorage();
    this.modalRefs.hide();
  }

  /**
   * 
   * @param listIndex list index from which card is to be removed.
   * @param cardIndex index of card to be removed.
   */
  removeCardFromList(listIndex, cardIndex): void {
    this.listCollections[listIndex].availableCards.splice(cardIndex, 1);
    this.updateSessionStorage();
  }

  sortCards(): void {
    this.listCollections.forEach((list) => {
      list.availableCards.sort(function (a, b) {
        return (new Date(b.cardCreationTime).getTime() - (new Date(a.cardCreationTime)).getTime())
      });
    })
  }

  /**D&D utils starts here */
  onDrop(event, droppingListIndex): void {
    event.stopPropagation();
    const draggedCard = this.listCollections[this.dragAndDropElementRef.listIndex].availableCards[this.dragAndDropElementRef.cardIndex];
    // check if element already exists in the list
    const ifCardExists = this.listCollections[droppingListIndex].availableCards.find((card) => card.cardTitle == draggedCard.cardTitle);
    if (ifCardExists) return;
    else {
      this.listCollections[droppingListIndex].availableCards.push({ ...draggedCard });
      this.listCollections[this.dragAndDropElementRef.listIndex].availableCards.splice(this.dragAndDropElementRef.cardIndex, 1);
      this.sortCards();

    }
    this.updateSessionStorage();
  }

  onDragOver(event) {
    event.stopPropagation();
    event.preventDefault();
  }

  /**
   * 
   * @param event - browser event object
   * @param listIndex - index of list from which items is being dragged.
   * @param cardIndex - index of card in the list which is being dragged.
   */
  dragStart(event, listIndex, cardIndex) {
    event.currentTarget.classList.add('dragging');
    this.dragAndDropElementRef = { listIndex, cardIndex };
  };

  dragEnd(event) {
    event.currentTarget.classList.remove('dragging');
  };

  updateSessionStorage() {
    sessionStorage.setItem('listCollections', JSON.stringify(this.listCollections));
  }

}

